'use client'

import { createClient } from '@utils/supabase/client'
import { useEffect, useState } from 'react'

type Todo = {
  id: string
  name: string
  done: boolean
  date: string
}

export default function TodoList({ initialTodos }: { initialTodos: Todo[] }) {
  const [todos, setTodos] = useState<Todo[]>(initialTodos)
  const supabase = createClient()

  useEffect(() => {
    const channels = supabase.channel('custom-all-channel')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'todos' },
        (payload) => {
          console.log('Change received!', payload)
          if (payload.eventType === 'INSERT') {
            setTodos(current => [...current, payload.new as Todo])
          } else if (payload.eventType === 'DELETE') {
            setTodos(current => current.filter(todo => todo.id !== payload.old.id))
          } else if (payload.eventType === 'UPDATE') {
            setTodos(current => 
              current.map(todo => 
                todo.id === payload.new.id ? payload.new as Todo : todo
              )
            )
          }
        }
      )
      .subscribe()

    return () => {
      channels.unsubscribe()
    }
  }, [supabase])

  return (
    <ul className="space-y-2">
      {todos?.map((todo) => (
        <li key={todo.id} className="flex items-center gap-2 p-2 bg-white/5 rounded">
          <input 
            type="checkbox" 
            checked={todo.done}
            onChange={async () => {
              const { error } = await supabase
                .from('todos')
                .update({ done: !todo.done })
                .eq('id', todo.id)
              
              if (error) console.error('Error updating todo:', error)
            }}
            className="w-4 h-4"
          />
          <span className={todo.done ? 'line-through text-gray-500' : ''}>
            {todo.name}
          </span>
          <span className="ml-auto text-sm text-gray-500">{new Date(todo.date).toLocaleDateString()}</span>
        </li>
      ))}
    </ul>
  )
} 